declare type Plugin$1 = any
