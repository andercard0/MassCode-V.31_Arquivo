declare module '@sipec/vue3-tags-input'
