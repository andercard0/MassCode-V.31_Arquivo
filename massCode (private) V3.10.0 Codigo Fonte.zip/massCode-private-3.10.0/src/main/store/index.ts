import app from './module/app'
import preferences from './module/preferences'

export const store = {
  app,
  preferences
}
