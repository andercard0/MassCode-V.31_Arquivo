export const { ipc, store, db, platform, i18n, version } = window.electron
