export type Type = 'encode' | 'decode'
