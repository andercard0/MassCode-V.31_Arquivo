export type Algo =
  | 'md5'
  | 'ripemd160'
  | 'sha1'
  | 'sha224'
  | 'sha256'
  | 'sha3'
  | 'sha384'
  | 'sha512'
